<?php
/**
 * Created by PhpStorm.
 * User: joaquin
 * Date: 19/03/18
 * Time: 18:56
 */

namespace App\Repositories\Mapper;


class PerfilMapper
{
    public function map($objeto)
    {
    }
}