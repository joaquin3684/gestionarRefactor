<?php
/**
 * Created by PhpStorm.
 * User: joaquin
 * Date: 06/03/18
 * Time: 18:41
 */

namespace App\Repositories\Mapper;


class RoleMapper
{

}